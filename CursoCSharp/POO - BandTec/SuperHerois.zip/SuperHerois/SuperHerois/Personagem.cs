﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SuperHerois
{
    abstract class Personagem : IPersonagem
    {
        private string nome;

        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }
        private string editora;

        public string Editora
        {
            get { return editora; }
            set { editora = value; }
        }
        private int pfInicial;

        public int PfInicial
        {
            get { return pfInicial; }
            set { pfInicial = value; }
        }
        private int peInicial;

        public int PeInicial
        {
            get { return peInicial; }
            set { peInicial = value; }
        }
        private int pf;

        public int Pf
        {
            get { return pf; }
            set { pf = value; }
        }
        private int pe;

        public int Pe
        {
            get { return pe; }
            set { pe = value; }
        }
        private bool mimico;

        public bool Mimico
        {
            get { return mimico; }
            set { mimico = value; }
        }
        private bool drenador;

        public bool Drenador
        {
            get { return drenador; }
            set { drenador = value; }
        }
        private List<Poder> poderes;

        internal List<Poder> Poderes
        {
            get { return poderes; }
            set { poderes = value; }
        }

        public Personagem(string nome, string editora, int pf, int pe, bool mimico,
            bool drenador)
        {
            this.nome = nome;
            this.editora = editora;
            this.pf = pf;
            this.pe = pe;
            this.mimico = mimico;
            this.drenador = drenador;
            this.pfInicial = pf;
            this.peInicial = pe;
            this.poderes = new List<Poder>();
        }

        public void Drenar(Personagem oponente)
        {
            if (drenador == true && oponente.pe > 0)
            {
                peInicial = peInicial + oponente.pe;
            }
        }

        public void ClonarPoderes(Personagem oponente)
        {
            if (mimico == true)
            {
                poderes.Clear();
                poderes.AddRange(oponente.poderes);
            }
        }

        public void AdicionaPoder(Poder poder)
        {
            poderes.Add(poder);
        }

        public void RemovePoder(Poder poder)
        {
            poderes.Remove(poder);
        }

        Random rd = new Random();
        
        public void Atacar(Personagem oponente)
        {
            
            int num = rd.Next(0, poderes.Count);


            if (this.pe >= poderes[num].Pe)
            {
                this.pe = this.pe - this.poderes[num].Pe;
                oponente.pf = oponente.pf - this.poderes[num].Dano;

                Console.WriteLine("{0}, usou seu poder {1} em {2}. Dano causado: {3}",
                    this.nome, this.poderes[num].Nome, oponente.Nome, this.poderes[num].Dano);

            }
            else
            {
                Recuperar();
            }
          

        }



        public void Recuperar()
        {
            this.pe = Convert.ToInt32(this.pe + this.peInicial * 0.3);
        }

        public void RecuperarTudo()
        {
            this.pf = pfInicial;
            this.pe = peInicial;
        }
    }
}
