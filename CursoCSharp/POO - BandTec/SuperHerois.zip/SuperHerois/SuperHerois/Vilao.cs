﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SuperHerois
{
    class Vilao : Personagem 
    {
        private int nivelDeMaldade;

        public int NivelDeMaldade
        {
            get { return nivelDeMaldade; }
            set { nivelDeMaldade = value; }
        }

        public Vilao(string nome, int nivelDeMaldade, string editora, int pf, int pe, bool mimico,
            bool drenador)
            : base(nome, editora, pf, pe, mimico, drenador)
        {
            this.nivelDeMaldade = nivelDeMaldade;
        }
    }
}
