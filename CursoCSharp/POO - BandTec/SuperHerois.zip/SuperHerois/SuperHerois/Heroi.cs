﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SuperHerois
{
    class Heroi : Personagem
    {
        private string nomeReal;

        public string NomeReal
        {
            get { return nomeReal; }
            set { nomeReal = value; }
        }

        public Heroi(string nome, string nomeReal, string editora, int pf, int pe, 
            bool mimico, bool drenador) 
            : base(nome, editora, pf, pe, mimico, drenador)
        {
            this.nomeReal = nomeReal;
        }
    }
}
