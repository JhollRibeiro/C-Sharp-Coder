﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SuperHerois
{
    class Poder
    {
        private string nome;

        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }
        private int dano;

        public int Dano
        {
            get { return dano; }
            set { dano = value; }
        }
        
        private int pe;

        public int Pe
        {
            get { return pe; }
            set { pe = value; }
        }

        public Poder(string nome, int dano, int pe)
        {
            this.nome = nome;
            this.dano = dano;
            this.pe = pe;
        }

     

        
    }
}
