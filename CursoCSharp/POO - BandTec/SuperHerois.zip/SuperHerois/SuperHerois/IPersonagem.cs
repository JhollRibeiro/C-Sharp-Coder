﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SuperHerois
{
    interface IPersonagem
    {
        void Atacar(Personagem oponente);

        void Recuperar();

        void RecuperarTudo();
    }
}
