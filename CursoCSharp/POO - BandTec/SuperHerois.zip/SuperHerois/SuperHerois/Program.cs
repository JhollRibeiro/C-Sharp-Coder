﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SuperHerois
{
    class Program
    {
        static void Main(string[] args)
        {
            Heroi hr1 = new Heroi("Superman", "Clark Kent", "DC Comics", 100, 70, false, false);
            Poder hr1pd1 = new Poder("Força", 10, 8);
            Poder hr1pd2 = new Poder("Visão de Raios", 5, 5);
            Poder hr1pd3 = new Poder("Supersopro", 4, 4);

            Heroi hr2 = new Heroi("Homem-Aranha", "Peter Parker", "Marvel Comics", 80, 50, false, false);
            Poder hr2pd1 = new Poder("Força", 7, 5);
            Poder hr2pd2 = new Poder("Soltar Teia", 5, 5);

            Heroi hr3 = new Heroi("Mimico", "Calvin Montgomery Rankin", "Marvel Comics", 70, 50, true, false);

            Vilao vl1 = new Vilao("Parasita", 70, "DC Comics", 90, 70, false, true);
            Poder vl1pd1 = new Poder("Força", 7, 8);
            Poder vl1pd2 = new Poder("Rajada de Energia", 6, 8);

            Vilao vl2 = new Vilao("Super Skrull", 100, "Marvel Comics", 90, 60, true, false);

            hr1.AdicionaPoder(hr1pd1);
            hr1.AdicionaPoder(hr1pd2);
            hr1.AdicionaPoder(hr1pd3);

            hr2.AdicionaPoder(hr2pd1);
            hr2.AdicionaPoder(hr2pd2);

            vl1.AdicionaPoder(vl1pd1);
            vl1.AdicionaPoder(vl1pd2);

            Confronto.Confrontar(hr1, hr2);
            Confronto.Confrontar(hr1, vl1);
            Confronto.Confrontar(vl1, vl2);
            Confronto.Confrontar(hr2, vl1);
            Confronto.Confrontar(vl1, hr2);



            Console.ReadKey();
        }
    }
}

