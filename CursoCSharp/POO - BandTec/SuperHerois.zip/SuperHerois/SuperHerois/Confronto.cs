﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SuperHerois
{
    static class Confronto
    {
        public static void Confrontar(Personagem oponente1, Personagem oponente2)
        {
            oponente1.RecuperarTudo();
            oponente2.RecuperarTudo();

            oponente1.ClonarPoderes(oponente2);
            oponente2.ClonarPoderes(oponente1);

            if (oponente1.Editora == oponente2.Editora)
            {
                Console.WriteLine("Confronto {0}", oponente2.Editora);

            }
            else
            {
                Console.WriteLine("Confronto CrossOver");

            }

            if (oponente1.GetType() == oponente2.GetType())
            {
                if (oponente1.GetType() == typeof(Heroi))
                {
                    Console.WriteLine("Confronto de Herói contra Herói!!!");
                    Console.WriteLine();
                }
                else
                {
                    Console.WriteLine("Confrontro de Vilão conta Vilão!!!");
                    Console.WriteLine();
                }
            }

            else
            {
                Console.WriteLine("Confronto Clássico: Bem VS Mal!!!");
                Console.WriteLine();
            }

            Console.WriteLine(oponente1.Nome + " Pontos de Força: " + oponente1.Pf);
            Console.WriteLine();
            Console.WriteLine(oponente2.Nome + " Pontos de Força: " + oponente2.Pf);
            Console.WriteLine();
            if (oponente1.Drenador == true)
            {
                Console.WriteLine("Drenador "+oponente1.Nome +" Pontos de Energia: "+oponente1.Pe);
                Console.WriteLine();
            }
            if (oponente2.Drenador == true)
            {
                Console.WriteLine("Drenador " + oponente2.Nome + " Pontos de Energia: " + oponente2.Pe);
                Console.WriteLine();
            }

            Random rd = new Random();


            while (oponente1.Pf > 0 && oponente2.Pf > 0)
            {
                int num = rd.Next(1, 3);

                if (num == 1)
                {
                    oponente1.Atacar(oponente2);
                    oponente2.Atacar(oponente1);
                }
                else if (num == 2)
                {
                    oponente2.Atacar(oponente1);
                    oponente1.Atacar(oponente2);
                }
            }

            Console.WriteLine();

            if (oponente1.Pf <= 0)
            {
                Console.WriteLine("Combate encerrado: Vencedor: {0}", oponente2.Nome);
                if (oponente2.Drenador == true)
                {
                    oponente2.Drenar(oponente1);
                }
            }
            else if (oponente2.Pf <= 0)
            {
                Console.WriteLine("Combate encerrado: Vencedor: {0}", oponente1.Nome);
                if (oponente1.Drenador == true)
                {
                    oponente1.Drenar(oponente2);
                }
            }
            Console.WriteLine();
            Console.WriteLine("-------------------------------------------------------------------------");
            Console.WriteLine();
        }
    }
}
